﻿//using System;
//using System.Collections.Generic;

//class Program
//{
//    static void Main(string[] args)
//    {
//        Console.WriteLine("Enter the number of elements");
//        int n = Convert.ToInt32(Console.ReadLine());
//        List<int> list = new List<int>();
//        Console.WriteLine("Enter the elements");
//        for(int i = 0; i<n;i++)
//        {
//            int a = Convert.ToInt32(Console.ReadLine());
//            list.Add(a);
//        }
//        GenericClass.SumOfElements<int>(list);
//        Console.Read();
//    }
//}
