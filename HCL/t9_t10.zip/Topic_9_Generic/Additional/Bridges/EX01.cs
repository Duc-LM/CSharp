﻿//using System;
//using System.Collections.Generic;


//internal class Program
//{
//    static void Main(string[] args)
//    {
//        int n = int.Parse(Console.ReadLine());
//        List<string> list = new List<string>();
//        for (int i = 0; i < n; i++)
//        {
//            string input = Console.ReadLine();
//            list.Add(input);
//        }
//        Console.WriteLine("Enter the hall name to search");
//        string searchName = Console.ReadLine();
//        int ind = list.IndexOf(searchName);
//        if (ind >= 0)
//            Console.WriteLine("Hall name {0} found at index {1}", searchName, ind);
//        else Console.WriteLine("Hall name not found");

//        Console.Read();
//    }
//}
