﻿//using System;

//class Program
//{
//    public static void Print<T>(T input)
//    {
//        Console.WriteLine(input);
//    }
//    static void Main(string[] args)
//    {
//        Console.WriteLine("Enter the input :");
//        string input = Console.ReadLine();
//        Print<string>(input);
//    }
//}


